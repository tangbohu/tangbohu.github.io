1) double click "SurfaceMatcher.exe" in the bin folder.
2) click "Read Scans" in the GUI to load the scene in the Data folder.
3) click "Align Scans" in the GUI to align the two scans.